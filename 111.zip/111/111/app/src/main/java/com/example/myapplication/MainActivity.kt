package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myapplication.ui.theme.MyApplicationTheme
import kotlinx.coroutines.delay
import java.time.LocalTime
import java.time.format.DateTimeFormatter

val ThaiFontFamily = FontFamily(
    Font(R.font.nkn) // ฟอนต์จาก res/font/nkn.ttf
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyApplicationTheme {
                MainScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen() {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "111",
                        color = Color.White,
                        style = TextStyle(
                            fontFamily = ThaiFontFamily,
                            fontSize = 24.sp
                        )
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF24B62A)
                )
            )
        }
    ) { paddingValues ->
        val context = LocalContext.current

        // จัด layout ให้อยู่กลางจอ
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            val currentTime = remember { mutableStateOf(LocalTime.now()) }
            LaunchedEffect(Unit) {
                while (true) {
                    delay(1000)
                    currentTime.value = LocalTime.now()
                }
            }

            // ปุ่มรูปเจ้าของ
            Button(
                onClick = {
                    val intent = Intent(context, SelfActivity::class.java)
                    context.startActivity(intent)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF24B62A), // พื้นหลังปุ่ม
                    contentColor = Color.White           // สีข้อความในปุ่ม
                ),
                modifier = Modifier
                    .padding(top = 16.dp)
                    .width(200.dp)
                    .height(60.dp)
            ) {
                Text("รูปตัวเอง", fontFamily = ThaiFontFamily)
            }

            // ปุ่มแฟนจ้า
            Button(
                onClick = {
                    val intent = Intent(context, FanActivity::class.java)
                    context.startActivity(intent)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF24B62A), // พื้นหลังปุ่ม
                    contentColor = Color.White           // สีข้อความในปุ่ม
                ),
                modifier = Modifier
                    .padding(top = 16.dp)
                    .width(200.dp)
                    .height(60.dp)
            ) {
                Text("รูปแฟน ", fontFamily = ThaiFontFamily)
            }

            // ข้อความชื่อและรหัส
            Text(
                text = "วัชรชัย นันทบุตร",
                style = TextStyle(fontSize = 22.sp, fontFamily = ThaiFontFamily),
                modifier = Modifier.padding(top = 19.dp)
            )
            Text(
                text = "66102122111",
                style = TextStyle(fontSize = 19.sp, fontFamily = ThaiFontFamily),
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun MainScreenPreview() {
    MyApplicationTheme {
        MainScreen()
    }
}
