package com.example.myapplication

import android.os.Bundle
import android.widget.ImageView
import androidx.activity.ComponentActivity
import com.squareup.picasso.Picasso

class FanActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fan)

        val imageView: ImageView = findViewById(R.id.fanImage)

        val imageUrl = "https://st.bigc-cs.com/cdn-cgi/image/format=webp,quality=90/public/media/catalog/product/90/88/8850918003790/8850918003790_7.jpg"

        Picasso.get()
            .load(imageUrl)
            .placeholder(R.drawable.ic_launcher_foreground) // รูประหว่างโหลด
            .error(R.drawable.ic_launcher_foreground)       // รูปกรณี error
            .into(imageView)
    }
}
